export class CreateITemDto {
    readonly name: string;
    readonly description:string;
    readonly qty: number;
}