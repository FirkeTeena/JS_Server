export default {
    mongoURI : 'URI FOR DB'
}